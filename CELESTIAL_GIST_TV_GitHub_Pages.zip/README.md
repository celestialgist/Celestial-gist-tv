# CELESTIAL GIST TV
Upload logo.png and gallery images into images/.